import os
import io
import sys
cwd = os.getcwd()
sys.path.insert(0, cwd)
from module.importData import importData
from module.toWordList import toWordList
from module.steamingWiki import steamingWiki
from module.makeModelGensim import makeModelGensim
from module.toVectore import toVectore
from module.modelLSTM import modelLSTM
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, cohen_kappa_score
import pandas as pd
import numpy as np
import gensim
from keras.models import load_model

np.set_printoptions(threshold=sys.maxsize)
pd.get_option("display.max_rows", 1000)
pd.set_option('display.max_columns', 1000)

wikiSource			= 'idwiki'
# answerData			= 'DataAnswerExam_SMP.csv'
# answerData			= 'aes.csv'
answerData			= 'aesnormal.csv'
# questionData		= 'DataQuestionExam_SMP.csv'
questionData		= 'qes.csv'
dirData				= cwd+'/data/'
corpusInput			= wikiSource+'.bz2'
wikiOutput			= wikiSource+'.txt'
fileExtension		= 'bin'
trainingAlgoritm	= 0
numDimension		= 200
modelOutput			= wikiSource+'_word2vec_'+str(numDimension)+'_'+str(trainingAlgoritm)+'.'+fileExtension


dAnswer, dQuestion = importData(answer= dirData+answerData, question= dirData+questionData).openData()

if not(os.path.exists(dirData+modelOutput)):
	if not(os.path.exists(dirData+wikiOutput)):
		steamingWiki(corpusInput=corpusInput, wikiOutput=wikiOutput).execute()
	makeModelGensim(wikiOutput=wikiOutput, modelOutput=modelOutput, numDimension=numDimension, trainingAlgoritm=trainingAlgoritm).execute()

if fileExtension != 'bin':
	model = gensim.models.word2vec.Word2Vec.load(dirData+modelOutput)
else:
	model = gensim.models.KeyedVectors.load_word2vec_format(dirData+modelOutput, unicode_errors='ignore')

msea =[]
maea =[]
kappa = []
file1 = io.open("small.txt", "w")
file2 = io.open("all.txt", "w")

for x in (dQuestion.loc[:,'Essay_id'].values):
	if x in dAnswer.loc[:,'Essay_id'].values:
		xdAnswer = dAnswer.loc[dAnswer['Essay_id'] == x]
		xdQuestion = dQuestion.loc[dQuestion['Essay_id'] == x]
		crossVal = KFold(n_splits=2, random_state=None, shuffle=True)
		results = []
		resultaa = []
		resultbb = []
		resultkappaa = []
		resultkappab = []
		resultkappac = []

		count = 1

		for dx, dy in crossVal.split(xdAnswer):
			df1 = pd.DataFrame() 
			df2 = pd.DataFrame() 
			dfa = pd.DataFrame() 
			dfb = pd.DataFrame() 
			dfc = pd.DataFrame() 
			trainStudentAnswer = []
			testStudentAnswer = []
			trueAnswer = []
			question = []
			
			print("\n--------Fold {}--------\n".format(count))
			train, test= xdAnswer.iloc[dx], xdAnswer.iloc[dy]
			
			xtrain = train.loc[:,['Answer']]
			xtest = test.loc[:,['Answer']]
			ytrain = train.loc[:,['Score']].values
			ytest = test.loc[:,['Score']].values
			
			[trainStudentAnswer.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xtrain.values]
			[testStudentAnswer.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xtest.values]
			[trueAnswer.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xdQuestion.loc[:,['Answer']].values]
			[question.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xdQuestion.loc[:,['Question']].values]    
			
			dataAnswerXTrain, dataTrueAnswerX = toVectore(essays = trainStudentAnswer, trueAnswer=trueAnswer, model = model, numFeature= numDimension, average=False, distance=True).changeToVector()
			dataAnswerYTest, dataTrueAnswerY = toVectore(essays = testStudentAnswer, trueAnswer=trueAnswer, model = model, numFeature= numDimension, average=False, distance=True).changeToVector()
			
			#modelNetworka = modelLSTM().getModel()
			#modelNetworkb = modelLSTM().getModel(rs=True)
			#modelNetworkb = modelLSTM().biGetModel(inputD=(dataAnswerXTrain.shape[1], dataAnswerXTrain.shape[2]))
			#modelNetworkc = modelLSTM().siamenseModel(inputD=(dataAnswerXTrain.shape[1], dataAnswerXTrain.shape[2]))
			modelNetworkd = modelLSTM().biSiamenseModel(inputD=(dataAnswerXTrain.shape[1], dataAnswerXTrain.shape[2]))
			#modelNetworka = load_model(dirData+'model/lstm_model_a'+str(x)+'.h5')
			#modelNetworkb = load_model(dirData+'model/lstm_model_b'+str(x)+'.h5')
            
            

			#modelNetworka.fit(dataAnswerXTrain, ytrain, batch_size=10, epochs=10)
			#modelNetworkb.fit(dataAnswerXTrain, ytrain, batch_size=10, epochs=10)
			#modelNetworkb.fit([dataAnswerXTrain, dataTrueAnswerX], ytrain, batch_size=25, epochs=100)
			modelNetworkd.fit([dataAnswerXTrain, dataTrueAnswerX], ytrain, batch_size=10, epochs=10)
			#ypred = modelNetworka.predict(dataAnswerXTest)
			ypred = modelNetworkd.predict([dataAnswerYTest, dataTrueAnswerY])
			#ypredb = modelNetworkb.predict(dataAnswerXTest)
			modelNetworkd.save_weights(dirData+'model/lstm_modelasdw_'+str(x)+'.h5')
			#dfa.insert(0,'actual',ytest.flatten())
			#dfa.insert(1,'predict',np.around(ypred).flatten())
			#dfb.insert(0,'actual',ytest.flatten())
			#dfb.insert(1,'predict',np.around(ypredb).flatten())
			#filea.write("==========="+str(x)+"========= fold "+str(count))
			#filea.write(str(dfa.values))
			#filea.write('\n')
			#fileb.write("==========="+str(x)+"========= fold "+str(count))
			#fileb.write(str(dfb.values))
			#fileb.write('\n')
			#resultkappaa.append(cohen_kappa_score(ytest, np.around(ypred), weights='quadratic'))
			#resultkappab.append(cohen_kappa_score(ytest, np.around(ypredb), weights='quadratic'))
			#resultkappac.append(cohen_kappa_score(ytest, np.around(ypredc), weights='quadratic'))
			#count += 1
		#filea.write("=======================================================")
		#filea.write('\n')
		#filea.write(str(resultkappaa))
		#fileb.write("=======================================================")
		#fileb.write('\n')
		#fileb.write(str(resultkappab))