import os
import io
import sys
cwd = os.getcwd()
sys.path.insert(0, cwd)
from module.importData import importData
from module.toWordList import toWordList
from module.steamingWiki import steamingWiki
from module.makeModelGensim import makeModelGensim
from module.toVectore import toVectore
from module.modelLSTM import modelLSTM
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, cohen_kappa_score
import pandas as pd
import numpy as np
import gensim
from keras.models import load_model

np.set_printoptions(threshold=sys.maxsize)
pd.get_option("display.max_rows", 1000)
pd.set_option('display.max_columns', 1000)

wikiSource			= 'idwiki'
answerData			= 'DataAnswerExam_SMP.csv'
# answerData			= 'aes.csv'
# answerData			= 'aesnormal.csv'
# answerData			= 'aesnormalitation.csv'
questionData		= 'DataQuestionExam_SMP.csv'
# questionData		= 'qes.csv'
dirData				= cwd+'/data/'
corpusInput			= wikiSource+'.bz2'
wikiOutput			= wikiSource+'.txt'
fileExtension		= 'bin'
trainingAlgoritm	= 0
numDimension		= 200
modelOutput			= wikiSource+'_word2vec_'+str(numDimension)+'_'+str(trainingAlgoritm)+'.'+fileExtension


dAnswer, dQuestion = importData(answer= dirData+answerData, question= dirData+questionData).openData()

if not(os.path.exists(dirData+modelOutput)):
	if not(os.path.exists(dirData+wikiOutput)):
		steamingWiki(corpusInput=corpusInput, wikiOutput=wikiOutput).execute()
	makeModelGensim(wikiOutput=wikiOutput, modelOutput=modelOutput, numDimension=numDimension, trainingAlgoritm=trainingAlgoritm).execute()

if fileExtension != 'bin':
	model = gensim.models.word2vec.Word2Vec.load(dirData+modelOutput)
else:
	model = gensim.models.KeyedVectors.load_word2vec_format(dirData+modelOutput, unicode_errors='ignore')

msea =[]
maea =[]
kappa = []
file1 = io.open("small.txt", "w")
file2 = io.open("all.txt", "w")
filea = io.open("ma.txt", "w")
fileb = io.open("mb.txt", "w")
filec = io.open("mc.txt", "w")

for x in (dQuestion.loc[:,'Essay_id'].values):
	if x in dAnswer.loc[:,'Essay_id'].values:
		xdAnswer = dAnswer.loc[dAnswer['Essay_id'] == x]
		xdQuestion = dQuestion.loc[dQuestion['Essay_id'] == x]
		crossVal = KFold(n_splits=4, random_state=None, shuffle=True)
		results = []
		resultaa = []
		resultbb = []
		resultkappaa = []
		resultkappab = []
		resultkappac = []

		count = 1

		for dx, dy in crossVal.split(xdAnswer):
			df1 = pd.DataFrame() 
			df2 = pd.DataFrame() 
			dfa = pd.DataFrame() 
			dfb = pd.DataFrame() 
			dfc = pd.DataFrame() 
			trainStudentAnswer = []
			testStudentAnswer = []
			trueAnswer = []
			question = []
			
			print("\n--------Fold {}--------\n".format(count))
			train, test= xdAnswer.iloc[dx], xdAnswer.iloc[dy]
			
			xtrain = train.loc[:,['Answer']]
			xtest = test.loc[:,['Answer']]
			ytrain = train.loc[:,['Score']].values
			ytest = test.loc[:,['Score']].values
			
			[trainStudentAnswer.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xtrain.values]
			[testStudentAnswer.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xtest.values]
			[trueAnswer.append(toWordList().sentenceToWordList(a1[0], changeNumber2Word= False, question=xdQuestion.loc[:,'Question'].values[0])) for a1 in xdQuestion.loc[:,['Answer']].values]
			
			dataAnswerTrain, dataTrueAnswerTrain = toVectore(essays = trainStudentAnswer, trueAnswer=trueAnswer, model = model, numFeature= numDimension, average=False, distance=True).changeToVector()
			# dataAnswerTrain1, dataTrueAnswerTrain1 = toVectore(essays = trainStudentAnswer, trueAnswer=trueAnswer, model = model, numFeature= numDimension, average=False, distance=False).changeToVector()
			dataAnswerTest, dataTrueAnswerTest = toVectore(essays = testStudentAnswer, trueAnswer=trueAnswer, model = model, numFeature= numDimension, average=False, distance=True).changeToVector()
			
			# modelNetworka = modelLSTM().getModel()
			# modelNetworkb = modelLSTM().getModel(rs=True)
			#modelNetworkb = modelLSTM().biGetModel(inputD=(dataAnswerXTrain.shape[1], dataAnswerXTrain.shape[2]))
			#modelNetworkc = modelLSTM().siamenseModel(inputD=(dataAnswerXTrain.shape[1], dataAnswerXTrain.shape[2]))
			modelNetworkd = modelLSTM().biSiamenseModel(inputD=(dataAnswerTrain.shape[1], dataTrueAnswerTrain.shape[2]))
			# modelNetworkd1 = modelLSTM().biSiamenseModel(inputD=(dataAnswerTrain.shape[1], dataTrueAnswerTrain.shape[2]), euclidean=True)
			# modelNetworkd2 = modelLSTM().biSiamenseModel(inputD=(dataAnswerTrain1.shape[1], dataTrueAnswerTrain1.shape[2]), euclidean=True)
			#modelNetworka = load_model(dirData+'model/lstm_model_a'+str(x)+'.h5')
			#modelNetworkb = load_model(dirData+'model/lstm_model_b'+str(x)+'.h5')
            
            

			# modelNetworka.fit(dataAnswerXTrain, ytrain, batch_size=10, epochs=10)
			# modelNetworkb.fit(dataAnswerXTrain, ytrain, batch_size=10, epochs=10)
			#modelNetworkb.fit([dataAnswerXTrain, dataTrueAnswerX], ytrain, batch_size=25, epochs=100)
			modelNetworkd.fit([dataAnswerTrain, dataTrueAnswerTrain], ytrain, batch_size=25, epochs=100)
			# modelNetworkd1.fit([dataAnswerTrain, dataTrueAnswerTrain], ytrain, batch_size=25, epochs=100)
			# modelNetworkd2.fit([dataAnswerTrain, dataTrueAnswerTrain], ytrain, batch_size=25, epochs=100)
			# ypred = modelNetworka.predict(dataAnswerXTest)
			ypredd = modelNetworkd.predict([dataAnswerTest, dataTrueAnswerTest])
			# ypredd1 = modelNetworkd1.predict([dataAnswerTest, dataTrueAnswerTest])
			# ypredd2 = modelNetworkd2.predict([dataAnswerTest, dataTrueAnswerTest])
			# ypredb = modelNetworkb.predict(dataAnswerXTest)
			dfa.insert(0,'actual',ytest.flatten())
			dfa.insert(1,'predict',np.around(ypredd).flatten())
			# dfb.insert(0,'actual',ytest.flatten())
			# dfb.insert(1,'predict',np.around(ypredd1).flatten())
			# dfc.insert(0,'actual',ytest.flatten())
			# dfc.insert(1,'predict',np.around(ypredd2).flatten())
			filea.write("==========="+str(x)+"========= fold "+str(count))
			filea.write(str(dfa.values))
			filea.write('\n')
			# fileb.write("==========="+str(x)+"========= fold "+str(count))
			# fileb.write(str(dfb.values))
			# fileb.write('\n')
			# filec.write("==========="+str(x)+"========= fold "+str(count))
			# filec.write(str(dfb.values))
			# filec.write('\n')
			resultkappaa.append(cohen_kappa_score(ytest, np.around(ypredd), weights='quadratic'))
			# resultkappab.append(cohen_kappa_score(ytest, np.around(ypredd1), weights='quadratic'))
			# resultkappac.append(cohen_kappa_score(ytest, np.around(ypredd2), weights='quadratic'))
			count += 1
		filea.write("=======================================================")
		filea.write('\n')
		filea.write(str(resultkappaa))
		# fileb.write("=======================================================")
		# fileb.write('\n')
		# fileb.write(str(resultkappab))
		# filec.write("=======================================================")
		# filec.write('\n')
		# filec.write(str(resultkappac))